﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double[] numbers = new double[100];
        double[] newNumbers = new double[100];
        Random rnd = new Random();
        private void GenButton_Click(object sender, EventArgs e)
        {
            double a = 0;
            double b = 0;
            double temp = 0;

            double normalSpreadLaw = 0;
            for (int i = 0; i < 100; i++)
            {
                numbers[i] = rnd.Next(1, 200);

                normalSpreadLaw = ((1 - (GetDispersion() * Math.Sqrt(2 * Math.PI))) * Math.Pow(Math.E, (-0.5 * (Math.Pow(((numbers[i] - GetMedian()) / GetDispersion()), 2)))));
                numbers[i] = normalSpreadLaw;
            }
            for (int i = 0; i < numbers.Length; i++)
            {
                for (int j = i + 1; j < numbers.Length; j++)
                {
                    if (numbers[i] < numbers[j])
                    {
                        temp = numbers[i];
                        numbers[i] = numbers[j];
                        numbers[j] = temp;
                    }
                }
            }

            for(int i = 0; i < newNumbers.Length-1; i++)
            {
                newNumbers[i] = numbers[i] - numbers[i + 1];
            }



            double resultDespersion = 0;
            double despersionNumbers = 0;
            double chanceNumbers = 0;
            double chance = 0.5;
            for(int i = 0; i < newNumbers.Length; i++)
            {
                despersionNumbers += Math.Pow(newNumbers[i], 2);
            }
            for (int i = 0; i < newNumbers.Length; i++)
            {
                chanceNumbers += Math.Pow(newNumbers[i] * chance, 2);
            }
            resultDespersion = (despersionNumbers - chanceNumbers) / newNumbers.Length;
            MessageBox.Show($"Дисперсия: {resultDespersion}");


            double resultMedian = 0;
            double MedianNumber = 0;
            for (int i = 0; i < newNumbers.Length; i++)
            {
                MedianNumber += newNumbers[i];
            }
            resultMedian = MedianNumber / newNumbers.Length;
            MessageBox.Show($"Среднее значение: {resultMedian}");


        }

        public double GetDispersion()
        {
            double numbers1 = 0;
            double numbers2 = 0;
            double chance = 0.5;
            double result = 0;
            for (int i = 0; i < 200; i++)
            {
                numbers2 += Math.Pow(i * chance, 2);
            }
            for (int i = 0; i < 200; i++)
            {
                numbers1 += Math.Pow(i,2);
            }
            result = (numbers1 - numbers2 ) / 200;
            return result;
        }
        public double GetMedian()
        {
            double numbers = 0;
            double result = 0;
            for (int i = 0; i < 200; i++)
            {
                numbers += i;
            }
            result = numbers / 200;
            return result;
        }
    }
}
